const settings = {
  packname: '𝙲𝙷𝙰𝙼𝙿-𝙼𝙳',
  author: '〔LALA G〕√',
  botName: "LALA G BOT",
  botOwner: 'MrlalaG', // Your name
  ownerNumber: '923007955325', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.2.0",
  updateZipUrl: "",
};

module.exports = settings;
